package com.smart.controller;

import java.io.File;
import java.io.IOException;
import java.lang.invoke.StringConcatFactory;
import java.nio.channels.Pipe.SourceChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.security.PublicKey;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.jar.Attributes.Name;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.smart.entities.Contact;
import com.smart.entities.User;
import com.smart.helper.Message;
import com.smart.repository.Userrepository;
import com.smart.repository.contactrepository;

import jakarta.servlet.http.HttpSession;
import jakarta.websocket.Session;

@Controller
@RequestMapping("/user")
public class Usercontroller {

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private Userrepository userrepository;
	
	@Autowired
	private contactrepository contactrepository;

	// method for adding common data to response
	@ModelAttribute
	public void addcommondata(Model model, Principal principal) {
		String username = principal.getName();
		System.out.println("username:" + username);

		// get the user using username(email)
		User user = userrepository.getuserbyusername(username);
		System.out.println("user:" + user);
		model.addAttribute(user);
	}

	// dashboard home
	@RequestMapping("/index")
	public String index(Model model, Principal principal) {
		model.addAttribute("title", "User Dashboard");
		return "normal/user_dashboard";
	}

	// open add form controller for add contact
	@GetMapping("/add-contact")
	public String openaddcontactform(Model model) {
		model.addAttribute("title", "Add-contact");
		model.addAttribute("contact", new Contact());
		return "normal/add_contact_form";
	}

	// processing add contact form
	@PostMapping("/process-contact")
	public String processContact(
	        @ModelAttribute Contact contact,
	        @RequestParam("profileimage") MultipartFile file,
	        Principal principal,HttpSession session,Model model){

	    try {
	        // Get the username from the principal
	        String name = principal.getName();
	        User user = this.userrepository.getuserbyusername(name);	
	        
	        //processing and uploading file
	        if(file.isEmpty()) {
	        	//if the file is empty then try our message
	        	System.out.println("file is empty");
	        	contact.setImage("calling.jpg");	        	
	        }
	        else {
	        	//file the file to folder and update the name to contact
	        	contact.setImage(file.getOriginalFilename());
	        	File file1=new ClassPathResource("static/img").getFile();
	        	
	       Path path =	Paths.get(file1.getAbsolutePath()+File.separator+file.getOriginalFilename());
	        	
	        	Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
	         System.out.println("image is uploaded");
	        }

	       
	       contact.setUser(user);
	       
	        user.getContacts().add(contact);

	    
	        this.userrepository.save(user);

	        System.out.println("Contact saved successfully."+contact);
	        System.out.println("added to database"); 
	        
	        model.addAttribute("message", new Message("Your contact is added !! Add more..","success"));
	       


        
	        return "normal/add_contact_form"; 

	    } catch (Exception e) {
	        // Handle exception
	        System.out.println("Error: " + e.getMessage());
	        e.printStackTrace();
	        
	        //message error
	       model.addAttribute("message", new Message("Something went wrong !! Try again..","danger"));

	        return "normal/add_contact_form"; 
	    }
	}
	
	//show contact handler
	//per page = 5[n]
	//current page =0[page]
	@GetMapping("/show-contact/{page}")
	public String showcontact(@PathVariable("page") Integer page ,Model model,Principal principal) {
		model.addAttribute("title","Show User Contact");
		//user ki list ko bhejni hai
		
		String username=principal.getName();
	User user=	this.userrepository.getuserbyusername(username);
	
	Pageable pageable=PageRequest.of(page, 3);
	
		Page<Contact>  contacts=this.contactrepository.findcontactbyuser(user.getId(),pageable);
		model.addAttribute("contacts",contacts);
		model.addAttribute("currentpage",page);
		model.addAttribute("totalpage",contacts.getTotalPages());
		return "normal/showcontact";
	}
	
	//showing particular contact detail\
	@RequestMapping("/contact/{cid}")
	public String showcontactdetail(@PathVariable("cid") Integer cid,Model model,Principal principal) {
		System.out.println("cid"+cid);
		
		Optional<Contact> contacts=this.contactrepository.findById(cid);
		Contact contact=contacts.get();
		
		//
		String username=principal.getName();
		 User user= this.userrepository.getuserbyusername(username);
		
		 if(user.getId()==contact.getUser().getId()) {
				model.addAttribute("contact",contact);
				model.addAttribute("title",contact.getName());

		 }
		 
		 
		return "normal/contact_detail";
	}
	
	//delete contact handler
	@GetMapping("/delete/{cid}")
	public String  deletecontact(@PathVariable ("cid") Integer cid,Model model,HttpSession session)
	{
		
		Contact contact=this.contactrepository.findById(cid).get();
		
		
		//it is for unlink the user to contact otherwise the contact will not deleted
		contact.setUser(null);
		//check...Assignment
        this.contactrepository.delete(contact);
		model.addAttribute("message", new Message("Contact deleted successfully","success"));
        
		return "redirect:/user/show-contact/0";
	}

	
	//open update handler
	@GetMapping("/update-contact/{cid}")
	public String updateform(@PathVariable("cid") Integer cid, Model model) {
		
		model.addAttribute("title","update contact");
		Contact contact=this.contactrepository.findById(cid).get();
            
		model.addAttribute("contact",contact);
		return "normal/update_form";
	}
	
	
	//update contact handler
	@RequestMapping(value = "/process-update", method = RequestMethod.POST)
	public String updateHandler(
	        @ModelAttribute Contact contact,
	        @RequestParam("profileimage") MultipartFile file,
	        Principal principal,
	        HttpSession session,Model model) {

	    try {
	        // Fetch the old contact details
	        Contact oldContactDetail = this.contactrepository.findById(contact.getCid())
	                .orElseThrow(() -> new RuntimeException("Contact not found for ID: " + contact.getCid()));

	        // Handle image upload
	        if (!file.isEmpty()) {
	            try {
	                // Save the new image
	                File uploadDir = new ClassPathResource("static/img").getFile();
	                Path path = Paths.get(uploadDir.getAbsolutePath() + File.separator + file.getOriginalFilename());
	                Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

	                // Update contact image
	                contact.setImage(file.getOriginalFilename());
	            } catch (IOException e) {
	                e.printStackTrace();
	                model.addAttribute("message", new Message("Error uploading image. Please try again.", "danger"));
	                return "redirect:/user/contacts";
	            }
	        } else {
	            // Retain the old image if no new image is uploaded
	            contact.setImage(oldContactDetail.getImage());
	        }

	        // Associate with the logged-in user
	        User user = this.userrepository.getuserbyusername(principal.getName());
	        contact.setUser(user);

	        // Save updated contact
	        this.contactrepository.save(contact);

	        // Success message
	        model.addAttribute("message", new Message("Contact successfully updated.", "success"));
	    } catch (Exception e) {
	        e.printStackTrace();
	     model.addAttribute("message", new Message("Error updating contact. Please try again.", "danger"));
	       // return "redirect:/user/contacts";
	    }

	    // Redirect to the updated contact details page
	    return "normal/contact_detail";
	}
	
	//your profile
	@GetMapping("/profile")
	public String yourprofile(Model model) {
		model.addAttribute("title","profile Page");
		return "normal/profile";
		
	}

	
	//open setting handler
	@GetMapping("/setting")
	public String opensetting() {
		return "normal/setting";
	}
	
	//change handler
	@PostMapping("/change-password")
		public String changepassword(@RequestParam("oldpassword")String oldpassword,@RequestParam("newpassword")String newpassword,Principal principal) {
		
		System.out.println("old password"+oldpassword);
		System.out.println("new password"+newpassword);
		
		String username=principal.getName();
		User currentuser=this.userrepository.getuserbyusername(username);

		if(this.bCryptPasswordEncoder.matches(oldpassword, currentuser.getPassword())) {
			//change the password
			currentuser.setPassword(this.bCryptPasswordEncoder.encode(newpassword));
			this.userrepository.save(currentuser);
		}else {
			//error
		}
		return "normal/user_dashboard";
	}
}

