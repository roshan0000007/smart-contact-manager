package com.smart.controller;

import java.security.Principal;
import java.security.PublicKey;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.smart.entities.Contact;
import com.smart.entities.User;
import com.smart.repository.Userrepository;
import com.smart.repository.contactrepository;

@RestController
public class Searchcontroller {
	
	@Autowired
	private contactrepository contactrepository;
	@Autowired
	private Userrepository userrepository;
	
	//search handler
	@GetMapping("/search/{query}")
	public ResponseEntity<?> search(@PathVariable("query")String query,Principal principal){
		 
		System.out.println(query);
		
		User user=userrepository.getuserbyusername(principal.getName());
		
	    List<Contact>contacts =this.contactrepository.findByNameContainingAndUser(query, user);
	
	    return ResponseEntity.ok(contacts);
	}

}
