package com.smart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smart.entities.Contact;
import com.smart.entities.User;
import com.smart.helper.Message;
import com.smart.repository.Userrepository;

import ch.qos.logback.core.model.Model;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class Homecontroller {
 
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	private Userrepository userrepository;
	@RequestMapping("/home")
	public String home(org.springframework.ui.Model model){	
		model.addAttribute("title","home-smart contact manager");
	      return "home";
	}
	
	@RequestMapping("/about")
	public String about(org.springframework.ui.Model model){	
		model.addAttribute("title","about-smart contact manager");
	      return "about";
	}
	
	@RequestMapping("/signup")
	public String signup(org.springframework.ui.Model model){	
		model.addAttribute("title","Register-smart contact manager");
		model.addAttribute("user",new User());
	      return "signup";
	}
	
	
		@RequestMapping(value = "/do_register", method = RequestMethod.POST)
		public String registerUser(
		     @ModelAttribute("user") User user,
		    
		    @RequestParam(value = "agreement", defaultValue = "false") boolean agreement,
		    org.springframework.ui.Model model,
		    HttpSession session
		) {
		    try {
		        if (!agreement) {
		            throw new Exception("You have not agreed to the terms and conditions.");
		        }
	
		      	
		        // Set additional user properties
		        user.setRole("ROLE_USER");
		        user.setEnabled(true);
		        user.setImageurl("default.png");
		        user.setPassword(passwordEncoder.encode(user.getPassword()));
	
		        // Save user to repository
		        User resultUser = userrepository.save(user);
	
		        model.addAttribute("user", new User());
		        session.setAttribute("message", new Message("Successfully Registered !!", "alert-success"));
		        return "signup";
		    } catch (Exception e) {
		        e.printStackTrace();
		        model.addAttribute("user", user);
		        session.setAttribute("message", new Message("Something went wrong !! " + e.getMessage(), "alert-danger"));
		        return "signup";
		    }
		}

	
		//handler for custom login
		@GetMapping("/signin")
	    public String customLogin(org.springframework.ui.Model model) {
	        model.addAttribute("title", "Login Page");
	        return "signin"; 
	    }
		
		
}
