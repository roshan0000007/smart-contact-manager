package com.smart.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.smart.entities.User;
import com.smart.helper.Message;
import com.smart.repository.Userrepository;
import com.smart.service.Emailservice;

import jakarta.servlet.http.HttpSession;

@Controller
public class Forgotcontroller {
	
	Random random =new Random(1000);
   
	@Autowired
	private Emailservice emailservice;
	
	@Autowired
	private Userrepository userrepository;
	
	@Autowired
	private BCryptPasswordEncoder bcrypt;
	
	//email id form  open handeler
	@RequestMapping("/forgot")
	public String openemailform() {
		
		
		return "forgot_email_form";
	}

	@PostMapping("/send-otp")
	public String sendotp(@RequestParam("email") String email,HttpSession session,Model model) {
		
		System.out.println("email"+email);
		//generating otp of 4 digit
		
		
		
	int otp=random.nextInt(9999);
		System.out.println("otp"+otp);
		
		//write code for send otp on email......
		
		String subject="OTP from SCM";
		String mesage=""
				+"<div style='border:1px solid #e2e2e2; padding:20px'>"
				+"<h1>"
				+"OTP is "
				+"<b>"+otp
				+"</n"
				+"</h1"
				+"</div>";
		 String to=email;
		 
		 boolean flag=this.emailservice.sendemail(subject, mesage, to);
		 
		 if(flag) {
			 
			 session.setAttribute("myotp",otp);             session.setAttribute("email", email);
			 return "verify_otp";
		 }
		 else {
			 
		        model.addAttribute("message", new Message("Failed to send OTP. Please try again!", "danger"));

			 return "forgot_email_form";
		 }
	}
	
	//verify otp
	
	@PostMapping("/verify-otp")
	public String verifyotp(@RequestParam("otp") int otp,HttpSession session,Model model) {
		
		int myOTP=(int) session.getAttribute("myotp");
		String email=(String)session.getAttribute("email");
		if(myOTP==otp) {             
			//password change form
			User user=this.userrepository.getuserbyusername(email);
		if(user==null) {
			//send error message
	        model.addAttribute("message", new Message("User does not Exist!!","danger"));
			return "forgot_email_form";
		}else {
			//send change password form
		
			
		}
			
			return "password_change_form";
			
		}else  {
			System.out.println("wrong otp");
	        model.addAttribute("message", new Message("You have entered wrong otp!!", "danger"));
			return "verify_otp";
		}
		
		
	}
	//change password
			@PostMapping("/change-password")
			public String changepassword(@RequestParam("newpassword") String newpassword,HttpSession session,Model model) {
				String email=(String)session.getAttribute("email");
				User user=this.userrepository.getuserbyusername(email);
				user.setPassword(this.bcrypt.encode(newpassword));
				this.userrepository.save(user);
		        model.addAttribute("message", new Message("New password save successfully !!", "success"));

				return "signin.html";
			}
}
