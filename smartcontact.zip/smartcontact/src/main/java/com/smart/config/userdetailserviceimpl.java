package com.smart.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.smart.entities.User;
import com.smart.repository.Userrepository;

public class userdetailserviceimpl implements UserDetailsService{

	@Autowired
	private Userrepository userrepository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		//fetching user from database
		
	User user	=userrepository.getuserbyusername(username);
	
	if(user==null) {
		throw new UsernameNotFoundException("could not found user !!");
	}
	
	customuserdetail customuserdetail=new customuserdetail(user);
	
		return customuserdetail;
	}

	
}
